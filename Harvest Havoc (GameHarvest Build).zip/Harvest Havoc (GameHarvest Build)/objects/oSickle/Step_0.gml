if (oControl.game_over) || (oControl.pause) || (oControl.timer_win) || (oControl.demo_win){
	grav = 0;
	//image_angle = image_angle;
	imageAngle = imageAngle
}
else {	
	//image_angle -= 2;
	imageAngle -= 2;
	grav = global.grav;
}

y_vel = grav;
y = y + y_vel;

objCheck = collision_rectangle(bbox_left, bbox_top, bbox_right, bbox_bottom, objects, false, false)
if (objCheck != noone)
{
	instance_destroy(self, false);
}

var playerCheck = instance_place(x, y, oFarmer)
if (playerCheck != noone){
	if (playerCheck.canDestroy){
		if (playerCheck.hasBoot) {
			global.player_score += 8000;
			global.score_text = 8000;
		}
		else {
			global.player_score += 4000;
			global.score_text = 4000;
		}
		
		if global.sfxControl audio_play_sound(sfxObstacle, 0, false);
		instance_destroy(self, false);
		instance_create_layer(x, y-10, "Info_Screen", oScorePopup);
		global.text_timer = 30;
		global.display_text = true;
	}
	else if (playerCheck.isInvincible){
	}
	else if (!playerCheck.isInvincible){
		instance_destroy(self, false);
		//show_debug_message("hello")
		if (global.player_lives > 0){
			//give player i-frames and knock them back a bit
			if global.sfxControl audio_play_sound(sfxHurt, 0, false);
			playerCheck.isInvincible = true;
			playerCheck.flashActive = true;
			/*if (playerCheck.isRight){
				playerCheck.x -= 40;
			}
			else{
				playerCheck.x += 40;
			}*/
		global.player_lives -=1;
		}
	else oControl.game_over = true;
	}
}