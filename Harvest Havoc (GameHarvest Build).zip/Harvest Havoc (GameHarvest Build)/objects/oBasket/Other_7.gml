if (oControl.timer_win) || (oControl.demo_win) || (oControl.game_over){
	sprite_index = sBasket;
	image_speed = 0;
	image_index = image_number - 1;
}