key_left = keyboard_check(vk_left) or keyboard_check(ord("A"));
key_right = keyboard_check(vk_right) or keyboard_check(ord("D"));


if (keyboard_check_pressed(vk_space) or keyboard_check_pressed(ord("P"))) && (!oControl.game_over){
	oControl.pause = true;
}

if (oControl.game_over) || (oControl.pause) || (oControl.timer_win) || (oControl.demo_win) var move = 0
else move = key_right - key_left;

if (hasBoot){
	horiz_move_speed = (move * walk_speed) * 2;
}
else{
	horiz_move_speed = move * walk_speed;
}
vert_move_speed = vert_move_speed + grav;


//Horizontal Geometry Collision
if (place_meeting(x+horiz_move_speed, y, terrain)){
	while(!place_meeting(x+sign(horiz_move_speed), y, terrain)){
		x = x + sign(horiz_move_speed);
	}
	horiz_move_speed = 0;
}
x = x + horiz_move_speed;

//Vertical Geometry Collision
if (place_meeting(x, y+vert_move_speed, terrain)){
	while(!place_meeting(x, y+sign(vert_move_speed), terrain)){
		y = y + sign(vert_move_speed);
	}
	vert_move_speed = 0;
}
y = y + vert_move_speed;


//Obstacle Detection
var shrubCheck = instance_place(x, y, fences)
if (shrubCheck != noone){
	if (isInvincible){
	}
	else if (!isInvincible){
		if global.player_lives > 0{
			//give player i-frames and knock them back a bit
			if global.sfxControl audio_play_sound(sfxBuzz, 0, false);
			isInvincible = true;
			flashActive = true;
			if (isRight){
				x -= 40;
			}
			else{
				x += 40;
			}
		global.player_lives -=1;
		}
	}
}
if (global.player_lives < 1){
	oControl.game_over = true;
}


//Keeping track of invincibility 
if (isInvincible){
	if (!oControl.pause){
		invincibleTimer -= 1;
		if (invincibleTimer < 0){
			isInvincible = false;
			invincibleTimer = 40;
			flashActive = false;
		}
	}
}

if (flashActive){
	if (!oControl.pause){
		if (flashSpeed % 4 == 0){
			if (flashAlpha == 0) flashAlpha = 1;
			else flashAlpha = 0
		}
		flashSpeed += 1;
	}
}

if (invincibleTimer == 40){
	flashAlpha = 0;
}

//Power Up Timers
if (hasBoot){
	//show_debug_message("this should be true")
	if (!oControl.pause){
		hasBootTimer -= 1;
		if (hasBootTimer == 10){
			if global.sfxControl audio_play_sound(sfxPowerdown, 0, false);
		}
		//show_debug_message("boot is active");
		if (hasBootTimer == 0){
			//show_debug_message("boot is gone")
			hasBoot = false;
			hasBootTimer = 400;
			
		}
	}
	if (oControl.game_over || oControl.timer_win) || (oControl.demo_win){
		hasBoot = false;
	}
	
}

if (canDestroy){
	if (!oControl.pause){
		canDestroyTimer -=1;
		if (canDestroyTimer == 10){
			if global.sfxControl audio_play_sound(sfxPowerdown, 0, false);
		}
		//show_debug_message("glove is active");
		if (canDestroyTimer == 0){
			//show_debug_message("glove is gone")
			canDestroy = false;
			canDestroyTimer = 400;
		}
	}
	if (oControl.game_over || oControl.timer_win) || (oControl.demo_win){
		canDestroy = false;
	}
	
}


//Animation
if (oControl.game_over){
	sprite_index = sFarmerGameOver;
	image_speed = 0.2;
}
else if (oControl.pause){
	image_speed = 0;
}
else if (horiz_move_speed !=0){
	if (canDestroy) && (hasBoot){
		sprite_index = sFarmerMove_Both;
		image_speed = 0.5;
	}
	else if (canDestroy){
		sprite_index = sFarmerMove_Glove;
		image_speed = 0.5;
	}
	else if (hasBoot){
		sprite_index = sFarmerMove_Boots;
		image_speed = 0.5;
	}
	else{
		sprite_index = sFarmerMove;
		image_speed = 0.5;
	}
}
else{
	if (canDestroy) && (hasBoot){
		sprite_index = sFarmerIdle_Both;
		image_speed = 0.5;
	}
	else if (canDestroy){
		sprite_index = sFarmerIdle_Glove;
		image_speed = 0.5;
	}
	else if (hasBoot){
		sprite_index = sFarmerIdle_Boots;
		image_speed = 0.5;
	}
	else{
		sprite_index = sFarmerIdle;
		image_speed = 0.5;
	}
}

if (horiz_move_speed !=0){ 
	image_xscale = sign(horiz_move_speed) * 1;
	isRight = sign(horiz_move_speed) > 0;
}