if (!oControl.pause){
	//show_debug_message("test 3")
	glove_text_timer -= 1;
	//show_debug_message(text_timer);
	if (glove_text_timer < 0){
		//show_debug_message("score is gone")
		instance_destroy(self, false);
		//global.GloveHelp = false;
		//ini_open("savedata.ini");
		//ini_write_real("firstTime", "Glove", global.GloveHelp);
		//ini_close();
	}
}