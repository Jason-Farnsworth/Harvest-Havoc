if (!oControl.game_over){
	if (!oControl.pause){
		if (global.player_score < 50000){
			global.normalNextScore = 50000 - global.player_score;
			if (spawnTimer % spawnTimerCutoff_Food == 0){
				var x_coord = random_range(200, 1200)
				var randObjectIndex = irandom(list_length_1 - 1);
				instance_create_layer(x_coord, y_coord, "Food", food[randObjectIndex]);
			}
			if (spawnTimer % spawnTimerCutoff_Obstacles == 0){
				var x_coord = random_range(200, 1200)
				var randObjectIndex = irandom(list_length_1 - 1);
				instance_create_layer(x_coord, y_coord, "Obstacles", obstacles[randObjectIndex]);
			}
			spawnTimer += 1;
		}
		else if (global.player_score < 100000){
			if (!reset_1) spawnTimer = 0;
			global.normalNextScore = 100000 - global.player_score;
			global.player_level = "Level 2";
			global.grav = 3;
			if (spawnTimer % spawnTimerCutoff_Food_2 == 0){
				var x_coord = random_range(200, 1200)
				var randObjectIndex = irandom(list_length_1 - 1);
				instance_create_layer(x_coord, y_coord, "Food", food[randObjectIndex]);
			}
			if (spawnTimer % spawnTimerCutoff_Obstacles_2 == 0){
				var x_coord = random_range(500, 510)
				var randObjectIndex = irandom(list_length_1 - 1);
				instance_create_layer(x_coord, y_coord, "Obstacles", obstacles[randObjectIndex]);
			}
			if (spawnTimer % spawnTimerCutoff_Power == 0){
				var x_coord = random_range(500, 510)
				var randObjectIndex = irandom(list_length_2 - 1);
				while (global.player_lives == 3) && (randObjectIndex < 2)
				{
					randObjectIndex = irandom(list_length_2 - 1);
				}
				instance_create_layer(x_coord, y_coord, "Powers", powerups[randObjectIndex]);
			}
			spawnTimer += 1;
			reset_1 = true;
		}
		else if (global.player_score < 200000){
			global.normalNextScore = 200000 - global.player_score;
			if (!reset_2) spawnTimer = 0;
			global.player_level = "Level 3";
			if (spawnTimer % spawnTimerCutoff_Food_3 == 0){
				var x_coord = random_range(200, 1200)
				var randObjectIndex = irandom(list_length_1 - 1);
				instance_create_layer(x_coord, y_coord, "Food", food[randObjectIndex]);
			}
			if (spawnTimer % spawnTimerCutoff_Obstacles_3 == 0){
				var x_coord = random_range(200, 1200)
				var randObjectIndex = irandom(list_length_1 - 1);
				instance_create_layer(x_coord, y_coord, "Obstacles", obstacles[randObjectIndex]);
			}
			if (spawnTimer % spawnTimerCutoff_Power == 0){
				var x_coord = random_range(400, 1000)
				var randObjectIndex = irandom(list_length_2 - 1);
				while (global.player_lives == 3) && (randObjectIndex < 2)
				{
					randObjectIndex = irandom(list_length_2 - 1);
				}
				instance_create_layer(x_coord, y_coord, "Powers", powerups[randObjectIndex]);
			}
			spawnTimer += 1;
			reset_2 = true;
		}
		else if (global.player_score < 300000){
			global.normalNextScore = 300000 - global.player_score;
			if (!reset_3) spawnTimer = 0;
			global.player_level = "Level 4";
			global.grav = 4;
			if (spawnTimer % spawnTimerCutoff_Food_4 == 0){
				var x_coord = random_range(200, 1200)
				var randObjectIndex = irandom(list_length_1 - 1);
				instance_create_layer(x_coord, y_coord, "Food", food[randObjectIndex]);
			}
			if (spawnTimer % spawnTimerCutoff_Obstacles_4 == 0){
				var x_coord = random_range(200, 1200)
				var randObjectIndex = irandom(list_length_1 - 1);
				instance_create_layer(x_coord, y_coord, "Obstacles", obstacles[randObjectIndex]);
			}
			if (spawnTimer % spawnTimerCutoff_Power == 0){
				var x_coord = random_range(400, 1000)
				var randObjectIndex = irandom(list_length_2 - 1);
				while (global.player_lives == 3) && (randObjectIndex < 2)
				{
					randObjectIndex = irandom(list_length_2 - 1);
				}
				instance_create_layer(x_coord, y_coord, "Powers", powerups[randObjectIndex]);
			}
			spawnTimer += 1;
			reset_3 = true;
		}
		y_coord = -50;
	}
}